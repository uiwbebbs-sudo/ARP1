String pkg = "com.rekoo.pubgm";

if (isChecked) {
    Execc("TURBO 2028 " + pkg);
}
